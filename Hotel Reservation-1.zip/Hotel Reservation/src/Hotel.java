public class Hotel {
	public static void main(String[] args) {
		LogInFrame lf = new LogInFrame();
		lf.setVisible(true);
	}

}
